

export function PageHeader({ title, subtitle }) {
  return (
    <div className="text-center mb-12">
      <h1 className="text-4xl md:text-5xl font-black tracking-tighter pb-2 bg-clip-text text-transparent bg-gradient-to-br from-primary via-primary to-accent animate-gradient bg-300%">
        {title}
      </h1>
      {subtitle && (
        <p className="mt-3 max-w-2xl mx-auto text-lg text-muted-foreground">
          {subtitle}
        </p>
      )}
    </div>
  );
}
