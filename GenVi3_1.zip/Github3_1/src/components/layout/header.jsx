"use client";

import Link from "next/link";
import { Leaf, Home, Info, Menu, Users, Calendar, Handshake, ImageIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger, SheetClose } from "@/components/ui/sheet";
import { usePathname } from 'next/navigation';
import { cn } from "@/lib/utils";
import React from "react";

const navLinks = [
  { href: "/", label: "Home", Icon: Home },
  { href: "/about", label: "About", Icon: Info },
  { href: "/speakers", label: "Speakers", Icon: Users },
  { href: "/events", label: "Events", Icon: Calendar },
  { href: "/team", label: "Team", Icon: Users },
  { href: "/gallery", label: "Gallery", Icon: ImageIcon },
  { href: "/sponsors", label: "Sponsors", Icon: Handshake },
];

export function Header() {
  const pathname = usePathname();

  const NavLink = ({ href, label }) => {
    const isActive = pathname === href;
    return (
      <Link
        href={href}
        className={cn(
          "rounded-md px-3 py-2 text-sm font-medium transition-colors",
          isActive
            ? "text-foreground bg-muted"
            : "text-muted-foreground hover:text-foreground"
        )}
      >
        {label}
      </Link>
    );
  };
  
  const MobileNavLink = ({ href, label, Icon }) => {
    const isActive = pathname === href;
    return (
        <SheetClose asChild>
          <Link href={href} className={cn(
                "flex items-center gap-4 rounded-lg p-3 text-base font-medium transition-colors",
                isActive ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-secondary hover:text-secondary-foreground"
              )}>
            
              <Icon className="h-5 w-5" />
              {label}
            
          </Link>
        </SheetClose>
    );
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 border-b border-border/50 bg-background/80 backdrop-blur-xl">
      <div className="container flex h-16 items-center justify-between px-4 md:px-6">
        <Link href="/" className="flex items-center gap-2 group mr-4">
          <div className="p-1.5 bg-primary rounded-lg transition-transform duration-300 group-hover:rotate-[-15deg]">
            <Leaf className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="text-lg font-bold tracking-tight text-foreground">EcoVerse</span>
        </Link>

        <nav className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <NavLink key={link.href} href={link.href} label={link.label} />
            ))}
        </nav>

        <div className="flex items-center gap-2 ml-auto">
          <Button asChild className="shine bg-accent text-accent-foreground hover:bg-accent/90 hidden md:flex">
            <Link href="/sponsors">Sponsor Us</Link>
          </Button>

          <div className="md:hidden">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Menu className="h-6 w-6" />
                  <span className="sr-only">Open menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-full max-w-xs">
                <div className="p-4">
                  <Link href="/" className="flex items-center gap-2 mb-8">
                    <div className="p-1.5 bg-primary rounded-lg">
                      <Leaf className="h-6 w-6 text-primary-foreground" />
                    </div>
                    <span className="text-xl font-bold tracking-tight text-foreground">EcoVerse</span>
                  </Link>
                  <div className="flex flex-col gap-2">
                      {navLinks.map((link) => (
                          <MobileNavLink key={link.href} {...link} />
                      ))}
                  </div>
                  <div className="mt-6 flex flex-col gap-2">
                    <SheetClose asChild>
                      <Button asChild className="w-full">
                        <Link href="/sponsors">Sponsor Us</Link>
                      </Button>
                    </SheetClose>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
