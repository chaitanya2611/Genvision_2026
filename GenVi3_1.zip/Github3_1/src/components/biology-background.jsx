
import React from 'react';
import { cn } from '@/lib/utils';

const SpikyVirus = ({ className, ...props }) => (
  <svg viewBox="0 0 100 100" className={cn("w-full h-full", className)} {...props}>
    <path d="M 50 20 A 30 30 0 1 1 49.9 20.1" fill="currentColor" opacity="0.7" />
    {[...Array(12)].map((_, i) => (
      <line
        key={i}
        x1="50"
        y1="50"
        x2={50 + 40 * Math.cos((i * 30 * Math.PI) / 180)}
        y2={50 + 40 * Math.sin((i * 30 * Math.PI) / 180)}
        className="stroke-current"
        strokeWidth="4"
        strokeLinecap="round"
      />
    ))}
  </svg>
);

const OvalBacteria = ({ className, ...props }) => (
    <svg viewBox="0 0 100 60" className={cn("w-full h-auto", className)} {...props}>
        <ellipse cx="50" cy="30" rx="35" ry="20" className="fill-current opacity-60" />
        <circle cx="40" cy="30" r="4" className="fill-current opacity-90" />
        <circle cx="60" cy="30" r="4" className="fill-current opacity-90" />
        <path d="M20 20 Q 10 30 20 40" className="stroke-current fill-none" strokeWidth="3" strokeLinecap="round" />
        <path d="M80 20 Q 90 30 80 40" className="stroke-current fill-none" strokeWidth="3" strokeLinecap="round" />
    </svg>
);

const SegmentedWorm = ({ className, ...props }) => (
    <svg viewBox="0 0 120 40" className={cn("w-full h-auto", className)} {...props}>
        <path d="M10 20 C 20 10, 40 10, 50 20 S 70 30, 80 20 S 100 10, 110 20" className="fill-none stroke-current" strokeWidth="10" strokeLinecap="round" />
        {[...Array(5)].map((_, i) => (
             <line key={i} x1={25 + i * 20} y1="15" x2={25 + i * 20} y2="25" className="stroke-current" strokeWidth="2" />
        ))}
    </svg>
);

const DottedCell = ({ className, ...props }) => (
    <svg viewBox="0 0 100 100" className={cn("w-full h-full", className)} {...props}>
        <circle cx="50" cy="50" r="35" className="fill-current opacity-50" />
        <circle cx="40" cy="40" r="5" className="fill-current opacity-80" />
        <circle cx="60" cy="45" r="7" className="fill-current opacity-80" />
        <circle cx="45" cy="60" r="6" className="fill-current opacity-80" />
        <circle cx="65" cy="65" r="4" className="fill-current opacity-80" />
    </svg>
);

const CrossBacteria = ({ className, ...props }) => (
    <svg viewBox="0 0 100 100" className={cn("w-full h-full", className)} {...props}>
        <rect x="40" y="20" width="20" height="60" rx="10" className="fill-current opacity-70" />
        <rect x="20" y="40" width="60" height="20" rx="10" className="fill-current opacity-70" />
    </svg>
);


const microorganisms = [
  { Component: SpikyVirus, size: 'w-16 h-16', animation: 'animate-[float-1_15s_ease-in-out_infinite]', top: '10%', left: '5%', color: 'text-accent' },
  { Component: OvalBacteria, size: 'w-24 h-24', animation: 'animate-[float-2_20s_ease-in-out_infinite]', top: '15%', left: '85%', color: 'text-primary' },
  { Component: DottedCell, size: 'w-20 h-20', animation: 'animate-[float-3_18s_ease-in-out_infinite]', top: '50%', left: '10%', color: 'text-accent' },
  { Component: SegmentedWorm, size: 'w-28 h-28', animation: 'animate-[float-1_22s_ease-in-out_infinite]', top: '80%', left: '20%', color: 'text-primary' },
  { Component: SpikyVirus, size: 'w-24 h-24', animation: 'animate-[float-2_16s_ease-in-out_infinite]', top: '65%', left: '90%', color: 'text-primary' },
  { Component: CrossBacteria, size: 'w-12 h-12', animation: 'animate-[float-3_25s_ease-in-out_infinite]', top: '30%', left: '30%', color: 'text-accent' },
  { Component: OvalBacteria, size: 'w-14 h-14', animation: 'animate-[float-1_19s_ease-in-out_infinite]', top: '88%', left: '5%', color: 'text-primary' },
  { Component: SpikyVirus, size: 'w-20 h-20', animation: 'animate-[float-2_14s_ease-in-out_infinite]', top: '5%', left: '50%', color: 'text-accent' },
  { Component: DottedCell, size: 'w-28 h-28', animation: 'animate-[float-3_21s_ease-in-out_infinite]', top: '85%', left: '65%', color: 'text-primary' },
  { Component: CrossBacteria, size: 'w-16 h-16', animation: 'animate-[float-1_12s_ease-in-out_infinite]', top: '40%', left: '60%', color: 'text-accent' },
  { Component: SegmentedWorm, size: 'w-20 h-20', animation: 'animate-[float-2_17s_ease-in-out_infinite]', top: '35%', left: '75%', color: 'text-primary' },
  { Component: DottedCell, size: 'w-12 h-12', animation: 'animate-[float-3_13s_ease-in-out_infinite]', top: '60%', left: '40%', color: 'text-accent' },
  { Component: SpikyVirus, size: 'w-14 h-14', animation: 'animate-[float-1_13s_ease-in-out_infinite]', top: '25%', left: '8%', color: 'text-primary' },
  { Component: OvalBacteria, size: 'w-20 h-20', animation: 'animate-[float-3_22s_ease-in-out_infinite]', top: '5%', left: '20%', color: 'text-accent' },
  { Component: SegmentedWorm, size: 'w-24 h-24', animation: 'animate-[float-2_19s_ease-in-out_infinite]', top: '90%', left: '90%', color: 'text-accent' },
  { Component: DottedCell, size: 'w-16 h-16', animation: 'animate-[float-1_16s_ease-in-out_infinite]', top: '75%', left: '50%', color: 'text-primary' },
  { Component: CrossBacteria, size: 'w-20 h-20', animation: 'animate-[float-3_24s_ease-in-out_infinite]', top: '55%', left: '75%', color: 'text-accent' },
  { Component: OvalBacteria, size: 'w-12 h-12', animation: 'animate-[float-2_12s_ease-in-out_infinite]', top: '20%', left: '65%', color: 'text-primary' },
];

export function BiologyBackground() {
  return (
    <div className="fixed inset-0 -z-10 overflow-hidden bg-background">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_25%_25%,hsl(var(--primary)/0.1),transparent_30%),radial-gradient(circle_at_75%_75%,hsl(var(--accent)/0.1),transparent_30%)]" />
        {microorganisms.map((microbe, index) => {
            const { Component, size, animation, top, left, color } = microbe;
            return (
                <div
                    key={index}
                    className={cn('absolute', size, animation, color)}
                    style={{ top, left }}
                >
                    <Component strokeWidth={1} />
                </div>
            );
        })}
    </div>
  );
}
