'use client';
import React, { createContext, useContext, useState, useEffect } from 'react';
import { MicroscopeIntro } from '@/components/microscope-intro';

const IntroContext = createContext();

export function useIntro() {
  return useContext(IntroContext);
}

export function IntroProvider({ children }) {
  const [introPlayed, setIntroPlayed] = useState(false);
  const [showIntro, setShowIntro] = useState(true);

  useEffect(() => {
    if (sessionStorage.getItem('introPlayed')) {
      setShowIntro(false);
      setIntroPlayed(true);
    } else {
      const timer = setTimeout(() => {
        setIntroPlayed(true);
        sessionStorage.setItem('introPlayed', 'true');
      }, 4500); // Wait for animation to finish
      return () => clearTimeout(timer);
    }
  }, []);

  return (
    <IntroContext.Provider value={{ introPlayed, showIntro }}>
      {children}
    </IntroContext.Provider>
  );
}

export function Intro({ children }) {
  const { showIntro, introPlayed } = useIntro();

  return (
    <>
      {showIntro && <MicroscopeIntro />}
      <div 
        className='fade-in'
        style={{ 
          opacity: introPlayed ? 1 : 0,
          transition: 'opacity 1s ease-in-out'
        }}
      >
        {children}
      </div>
    </>
  );
}
