'use client';
import React, { useRef, useState } from 'react';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { Card, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { ArrowRight } from 'lucide-react';
import { FloatingGermPin } from './floating-germ-pin';

const ROTATION_RANGE = 20;
const HALF_ROTATION_RANGE = ROTATION_RANGE / 2;

export function TiltCard({ title, description, href, Icon, className }) {
  const ref = useRef(null);
  const [rotateX, setRotateX] = useState(0);
  const [rotateY, setRotateY] = useState(0);

  const handleMouseMove = (e) => {
    if (!ref.current) return;

    const rect = ref.current.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    const xPct = mouseX / width - 0.5;
    const yPct = mouseY / height - 0.5;

    setRotateX(yPct * -ROTATION_RANGE);
    setRotateY(xPct * ROTATION_RANGE);
  };

  const handleMouseLeave = () => {
    setRotateX(0);
    setRotateY(0);
  };

  return (
    <motion.div
      ref={ref}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={{
        transformStyle: 'preserve-3d',
      }}
      animate={{
        rotateX,
        rotateY,
      }}
      className={cn('relative w-full rounded-xl pt-3', className)}
    >
      <FloatingGermPin className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-8 z-10" />
      <Link
        href={href}
        className="block h-full"
        style={{
          transform: 'translateZ(75px)',
          transformStyle: 'preserve-3d',
        }}
      >
        <Card
          className="h-full border-border/60 bg-card/50 text-card-foreground backdrop-blur-sm transition-all duration-300 hover:border-primary/50 hover:shadow-xl hover:shadow-primary/10 group"
        >
          <CardHeader className="p-8">
            <div
              style={{
                transform: 'translateZ(50px)',
              }}
              className="mb-4"
            >
              <Icon className="w-10 h-10 text-primary" />
            </div>
            <CardTitle 
              className="text-xl"
              style={{
                transform: 'translateZ(50px)',
              }}
            >
              {title}
            </CardTitle>
            <CardDescription
              className="pt-2"
              style={{
                transform: 'translateZ(40px)',
              }}
            >
              {description}
            </CardDescription>

            <div className="absolute bottom-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <ArrowRight className="w-6 h-6 text-primary" />
            </div>
          </CardHeader>
        </Card>
      </Link>
    </motion.div>
  );
}
