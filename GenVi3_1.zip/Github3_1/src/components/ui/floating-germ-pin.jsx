import { cn } from '@/lib/utils';
import React from 'react';

// A simple, stylized germ SVG component for the pin
export const FloatingGermPin = ({ className, ...props }) => (
  <svg
    viewBox="0 0 100 80"
    className={cn("w-full h-full text-primary", className)}
    {...props}
  >
    <g transform="rotate(-30 50 40)">
      <path
        d="M 50,40 m -20,0 a 20,20 0 1,0 40,0 a 20,20 0 1,0 -40,0"
        className="fill-current opacity-30"
      />
      <circle cx="50" cy="40" r="10" className="fill-current opacity-70" />
      <line
        x1="30"
        y1="40"
        x2="10"
        y2="40"
        className="stroke-current opacity-80"
        strokeWidth="5"
        strokeLinecap="round"
      />
       <line
        x1="70"
        y1="40"
        x2="90"
        y2="40"
        className="stroke-current opacity-80"
        strokeWidth="5"
        strokeLinecap="round"
      />
       <line
        x1="50"
        y1="20"
        x2="50"
        y2="0"
        className="stroke-current opacity-80"
        strokeWidth="5"
        strokeLinecap="round"
      />
    </g>
  </svg>
);
