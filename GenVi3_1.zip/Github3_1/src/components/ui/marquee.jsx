
"use client";
import { cn } from "@/lib/utils";
import React from "react";

export function Marquee({
    className,
    children,
    ...props
  }) {
  return (
    <div className={cn("relative flex w-full overflow-x-hidden border-y", className)} {...props}>
      <div className="animate-marquee whitespace-nowrap py-3 flex">
        {children}
      </div>
      <div className="animate-marquee absolute top-0 whitespace-nowrap py-3 flex">
        {children}
      </div>
    </div>
  );
}
