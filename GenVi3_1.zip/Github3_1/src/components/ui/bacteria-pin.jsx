import { cn } from '@/lib/utils';
import React from 'react';

// A simple, stylized bacteria SVG component for the pin
export const BacteriaPin = ({ className, ...props }) => (
  <svg
    viewBox="0 0 100 80"
    className={cn("w-full h-full", className)}
    {...props}
  >
    <g transform="rotate(-30 50 40)">
      <path
        d="M 20 40 a 20 20 0 1 1 60 0 a 20 20 0 1 1 -60 0"
        className="fill-primary/30 stroke-primary/80"
        strokeWidth="4"
      />
      <line
        x1="10"
        y1="40"
        x2="-5"
        y2="30"
        className="stroke-primary/80"
        strokeWidth="5"
        strokeLinecap="round"
      />
      <line
        x1="12"
        y1="48"
        x2="-10"
        y2="48"
        className="stroke-primary/80"
        strokeWidth="5"
        strokeLinecap="round"
      />
      <line
        x1="10"
        y1="55"
        x2="-5"
        y2="65"
        className="stroke-primary/80"
        strokeWidth="5"
        strokeLinecap="round"
      />
    </g>
  </svg>
);
