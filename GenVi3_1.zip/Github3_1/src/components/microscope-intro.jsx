'use client';

const MicroscopeSVG = () => (
  <svg viewBox="0 0 200 200" className="w-96 h-96 text-gray-300">
    <defs>
      <radialGradient id="lens-gradient" cx="0.5" cy="0.5" r="0.5">
        <stop offset="0%" stopColor="#222" />
        <stop offset="70%" stopColor="#111" />
        <stop offset="95%" stopColor="#333" />
        <stop offset="100%" stopColor="#555" />
      </radialGradient>
      <radialGradient id="lens-highlight" cx="0.3" cy="0.3" r="0.7">
        <stop offset="0%" stopColor="rgba(255,255,255,0.3)" />
        <stop offset="100%" stopColor="rgba(255,255,255,0)" />
      </radialGradient>
      <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
        <feGaussianBlur in="SourceAlpha" stdDeviation="3" />
        <feOffset dx="2" dy="2" result="offsetblur" />
        <feComponentTransfer>
          <feFuncA type="linear" slope="0.5" />
        </feComponentTransfer>
        <feMerge>
          <feMergeNode />
          <feMergeNode in="SourceGraphic" />
        </feMerge>
      </filter>
    </defs>

    <g transform="matrix(1, 0, 0, 1, 0, 0)" filter="url(#shadow)">
      {/* Main Body */}
      <path d="M 40 50 L 160 50 L 170 80 L 30 80 Z" fill="#E5E7EB" />
      <path d="M 50 50 L 150 50 L 150 40 L 50 40 Z" fill="#D1D5DB" />

      {/* Eyepieces */}
      <g transform="translate(0, 20)">
        <path d="M 55 50 L 45 100 L 95 100 L 85 50 Z" fill="#374151" />
        <path
          d="M 145 50 L 155 100 L 105 100 L 115 50 Z"
          fill="#374151"
        />

        {/* Left Eyepiece */}
        <circle cx="70" cy="50" r="28" fill="#9CA3AF" />
        <circle cx="70"cy="50" r="25" fill="url(#lens-gradient)" />
        <circle cx="70" cy="50" r="10" fill="#000" />
        <circle cx="70" cy="50" r="5" fill="#4B5563" />
        <circle cx="70" cy="50" r="25" fill="url(#lens-highlight)" />

        {/* Right Eyepiece */}
        <circle cx="130" cy="50" r="28" fill="#9CA3AF" />
        <circle cx="130" cy="50" r="25" fill="url(#lens-gradient)" />
        <circle cx="130" cy="50" r="10" fill="#000" />
        <circle cx="130" cy="50" r="5" fill="#4B5563" />
        <circle cx="130" cy="50" r="25" fill="url(#lens-highlight)" />

        {/* Focus Knobs */}
        <rect x="25" y="45" width="15" height="20" rx="3" fill="#4B5563" />
        <rect x="160" y="45" width="15" height="20" rx="3" fill="#4B5563" />
      </g>

      {/* Stage and Light */}
      <path d="M 60 120 L 140 120 L 145 140 L 55 140 Z" fill="#D1D5DB" />
      <circle cx="100" cy="118" r="8" fill="hsl(var(--primary)/0.5)" />
      <circle cx="100" cy="118" r="5" fill="hsl(var(--primary)/0.8)" />
    </g>
  </svg>
);


export function MicroscopeIntro() {
  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center bg-background animate-[intro-fade-out_4.5s_ease-out_forwards]"
    >
      <div className="flex flex-col items-center gap-8 animate-[microscope-zoom-in_4s_ease-in-out_forwards]">
        <MicroscopeSVG />
      </div>
    </div>
  );
}
