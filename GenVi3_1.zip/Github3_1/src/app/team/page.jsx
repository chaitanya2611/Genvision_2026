
import { PageHeader } from '@/components/page-header';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { TeamCard } from './team-card';

const team = [
  {
    name: 'Dr. Evelyn Reed',
    title: 'Founder & CEO',
    bio: 'A visionary leader with a passion for merging technology with ecology to create a sustainable future.',
    imageId: 'team-1'
  },
  {
    name: 'Leo Chen',
    title: 'Head of Engineering',
    bio: 'Leads our talented engineering team, building the core infrastructure that powers our global initiatives.',
    imageId: 'team-2'
  },
  {
    name: 'Sofia Garcia',
    title: 'Director of Research',
    bio: 'Oversees all research operations, ensuring our projects are scientifically rigorous and impactful.',
    imageId: 'team-3'
  },
  {
    name: 'David Kim',
    title: 'Lead Product Designer',
    bio: 'Designs intuitive and beautiful interfaces that make complex environmental data accessible to everyone.',
    imageId: 'team-4'
  },
];

const getTeamMemberWithImage = (member) => {
  const image = PlaceHolderImages.find(img => img.id === member.imageId);
  return { ...member, image };
}

export default function TeamPage() {
  return (
    <div className="container mx-auto px-4 py-16 relative z-10">
      <PageHeader
        title="Our Team"
        subtitle="Meet the dedicated and passionate individuals who are the driving force behind EcoVerse."
      />
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mt-16 perspective-1000">
        {team.map((member) => (
          <TeamCard key={member.name} {...getTeamMemberWithImage(member)} image={getTeamMemberWithImage(member).image} />
        ))}
      </div>
    </div>
  );
}
