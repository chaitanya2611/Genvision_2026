
import Image from 'next/image';
import Link from 'next/link';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Mail, Linkedin } from 'lucide-react';
import { FloatingGermPin } from '@/components/ui/floating-germ-pin';

export function TeamCard({ name, title, bio, image }) {
  return (
    <div className="relative pt-3 h-full">
       <FloatingGermPin className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-8 z-10" />
      <Card className="text-center flex flex-col h-full overflow-hidden border-border/60 bg-card/50 backdrop-blur-sm transition-all duration-300 transform-style-3d hover:shadow-xl hover:shadow-primary/10 hover:[transform:rotateY(-10deg)_rotateX(5deg)_translateZ(20px)]">
        <CardHeader className="p-0">
          <div className="relative aspect-square">
            {image ? (
                <Image
                src={image.imageUrl}
                alt={`Portrait of ${name}`}
                fill
                className="object-cover"
                data-ai-hint={image.imageHint}
                />
            ) : (
                <div className="w-full h-full bg-muted flex items-center justify-center">
                    <span className="text-muted-foreground">No Image</span>
                </div>
            )}
          </div>
        </CardHeader>
        <CardContent className="p-6 flex-grow">
          <CardTitle className="text-lg">{name}</CardTitle>
          <CardDescription className="text-primary mt-1 text-sm">{title}</CardDescription>
          <p className="text-muted-foreground text-sm mt-3">{bio}</p>
        </CardContent>
        <CardFooter className="flex justify-center gap-4 pb-6">
          <Link href="#" aria-label={`Email ${name}`}>
            <Mail className="h-5 w-5 text-muted-foreground hover:text-primary transition-colors" />
          </Link>
          <Link href="#" aria-label={`${name}'s LinkedIn`}>
            <Linkedin className="h-5 w-5 text-muted-foreground hover:text-primary transition-colors" />
          </Link>
        </CardFooter>
      </Card>
    </div>
  );
}
