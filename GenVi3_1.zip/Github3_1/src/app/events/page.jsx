
import { PageHeader } from '@/components/page-header';
import { EventCard } from './event-card';

const events = [
  {
    name: 'Global Climate Summit 2024',
    date: '2024-10-15',
    location: 'Virtual',
    description: 'Join world leaders, scientists, and activists in discussing the future of our planet. This summit will focus on actionable strategies for mitigating climate change and fostering international cooperation.',
    image: { id: 'event-1', imageHint: 'conference climate change' }
  },
  {
    name: 'Biodiversity Conservation Gala',
    date: '2024-11-05',
    location: 'London, UK',
    description: 'An exclusive evening dedicated to raising funds for endangered species. The event will feature a silent auction, keynote speakers, and a celebration of our conservation successes.',
    image: { id: 'event-2', imageHint: 'gala event' }
  },
  {
    name: 'Tech for Trees Hackathon',
    date: '2024-12-01',
    location: 'Online',
    description: 'A 48-hour virtual hackathon where developers, designers, and environmentalists collaborate to build innovative solutions for reforestation and forest monitoring. Prizes for the most impactful projects.',
    image: { id: 'event-3', imageHint: 'hackathon computer' }
  },
  {
    name: 'Community Cleanup Day',
    date: '2025-01-20',
    location: 'Local Parks Worldwide',
    description: 'A global initiative to clean up our local communities. Join a team in your area to make a tangible impact, connect with fellow nature lovers, and help restore the beauty of our public spaces.',
    image: { id: 'event-4', imageHint: 'community cleanup' }
  }
];

export default function EventsPage() {
  return (
    <div className="container mx-auto px-4 py-16 relative z-10">
      <PageHeader
        title="Upcoming Events"
        subtitle="Join us at our next event to learn, connect, and contribute to a healthier planet."
      />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-12 mt-16 perspective-1000">
        {events.map((event) => (
          <EventCard key={event.name} {...event} />
        ))}
      </div>
    </div>
  );
}
