
'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { motion } from 'framer-motion';
import { Calendar, MapPin } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { Button } from '@/components/ui/button';
import { FloatingGermPin } from '@/components/ui/floating-germ-pin';

export function EventCard({ name, date, location, description, image }) {
  const [isFlipped, setIsFlipped] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);
  const placeholderImage = PlaceHolderImages.find(p => p.id === image.id);

  function handleFlip() {
    if (!isAnimating) {
      setIsFlipped(!isFlipped);
      setIsAnimating(true);
    }
  }

  return (
    <div
      className="relative transform-style-3d h-[450px]"
      onMouseEnter={() => !isFlipped && handleFlip()}
      onMouseLeave={() => isFlipped && handleFlip()}
    >
      <motion.div
        className="absolute w-full h-full transform-style-3d"
        initial={false}
        animate={{ rotateY: isFlipped ? 180 : 360 }}
        transition={{ duration: 0.6, ease: 'easeInOut' }}
        onAnimationComplete={() => setIsAnimating(false)}
      >
        {/* Front of the card */}
        <div className="absolute w-full h-full backface-hidden pt-3">
          <FloatingGermPin className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-8 z-20" />
          <Card className="w-full h-full overflow-hidden border-border/60 bg-card/50 backdrop-blur-sm">
            {placeholderImage && (
              <div className="relative h-2/3">
                <Image
                  src={placeholderImage.imageUrl}
                  alt={`Image for ${name}`}
                  fill
                  className="object-cover"
                  data-ai-hint={placeholderImage.imageHint}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
              </div>
            )}
            <CardHeader>
              <CardTitle className="text-lg">{name}</CardTitle>
              <div className="flex items-center gap-4 text-sm text-muted-foreground pt-1">
                <div className="flex items-center gap-1.5">
                  <Calendar className="h-4 w-4 text-primary" />
                  <span>{new Date(date).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <MapPin className="h-4 w-4 text-primary" />
                  <span>{location}</span>
                </div>
              </div>
            </CardHeader>
          </Card>
        </div>

        {/* Back of the card */}
        <div className="absolute w-full h-full backface-hidden rotate-y-180 pt-3">
            <FloatingGermPin className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-8 z-20" />
            <Card className="w-full h-full flex flex-col justify-between border-border/60 bg-card/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-lg">{name}</CardTitle>
              <div className="flex items-center gap-4 text-xs text-muted-foreground">
                <div className="flex items-center gap-1.5"><Calendar className="h-4 w-4 text-primary" /><span>{date}</span></div>
                <div className="flex items-center gap-1.5"><MapPin className="h-4 w-4 text-primary" /><span>{location}</span></div>
              </div>
            </CardHeader>
            <CardContent>
              <CardDescription>{description}</CardDescription>
            </CardContent>
            <CardFooter>
              <Button className='w-full shine'>Register Now</Button>
            </CardFooter>
          </Card>
        </div>
      </motion.div>
    </div>
  );
}
