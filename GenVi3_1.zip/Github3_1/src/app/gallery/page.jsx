
import { PageHeader } from '@/components/page-header';
import { Card, CardContent } from '@/components/ui/card';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import Image from 'next/image';

const galleryImages = [
  'gallery-group-1',
  'gallery-group-2',
  'gallery-group-3',
  'gallery-group-4',
  'gallery-group-5',
  'gallery-group-6',
];

export default function GalleryPage() {
  const images = galleryImages.map(id => PlaceHolderImages.find(img => img.id === id)).filter(Boolean);

  return (
    <div className="container mx-auto px-4 py-16 relative z-10">
      <PageHeader
        title="Community Gallery"
        subtitle="A collection of moments showcasing collaboration, community, and connection."
      />
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 mt-16">
        {images.map((image) => (
          <Card key={image.id} className="overflow-hidden group">
            <CardContent className="p-0">
              <div className="relative aspect-square w-full">
                <Image
                  src={image.imageUrl}
                  alt={image.description}
                  fill
                  className="object-cover transition-transform duration-300 group-hover:scale-105"
                  data-ai-hint={image.imageHint}
                />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
