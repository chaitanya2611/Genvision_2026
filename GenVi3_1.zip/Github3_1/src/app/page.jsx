
'use client';
import React from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { ArrowRight, Leaf, Calendar, Users, Handshake } from 'lucide-react';
import { TiltCard } from '@/components/ui/tilt-card';

const cards = [
  {
    title: 'Our Mission',
    description: 'Discover our goals and the core values that drive our environmental initiatives.',
    href: '/about',
    Icon: Leaf,
  },
  {
    title: 'Upcoming Events',
    description: 'Join our webinars, workshops, and community activities to get involved.',
    href: '/events',
    Icon: Calendar,
  },
  {
    title: 'Our Team',
    description: 'Meet the passionate individuals behind EcoVerse who are making a difference.',
    href: '/team',
    Icon: Users,
  },
  {
    title: 'Sponsors',
    description: 'Learn about the organizations that support our mission for a greener future.',
    href: '/sponsors',
    Icon: Handshake,
  },
];

export default function HomePage() {
  return (
    <>
      <div className="container mx-auto px-4 py-16 relative z-10">
        <section className="text-center mb-20">
          <h1 className="text-5xl md:text-7xl font-black tracking-tighter pb-4 bg-clip-text text-transparent bg-gradient-to-br from-primary via-accent to-primary animate-gradient bg-300%">
            EcoVerse
          </h1>
          <p className="mt-6 max-w-3xl mx-auto text-lg md:text-xl text-muted-foreground">
            Harnessing technology to build a sustainable future and protect our planet's biodiversity.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button asChild size="lg" className="shine">
              <Link href="/about">
                Explore Our Mission <ArrowRight />
              </Link>
            </Button>
            <Button asChild size="lg" variant="secondary">
              <Link href="/events">Join an Event</Link>
            </Button>
          </div>
        </section>

        <section className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {cards.map((card, index) => (
            <TiltCard key={card.title} {...card} />
          ))}
        </section>
      </div>
    </>
  );
}
