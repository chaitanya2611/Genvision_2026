
import { PageHeader } from '@/components/page-header';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import Image from 'next/image';
import { FloatingGermPin } from '@/components/ui/floating-germ-pin';

const sponsors = [
  { id: 'sponsor-1', name: 'GreenTech Solutions' },
  { id: 'sponsor-2', name: 'EcoInnovate Fund' },
  { id: 'sponsor-3', name: 'NatureFirst Corp' },
  { id: 'sponsor-4', name: 'Sustainable Futures Inc.' },
];

export default function SponsorsPage() {
  return (
    <div className="container mx-auto px-4 py-16 relative z-10">
      <PageHeader
        title="Our Sponsors"
        subtitle="We are grateful for the generous support of our partners who make our work possible."
      />
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mt-16">
        {sponsors.map((sponsor) => {
          const image = PlaceHolderImages.find((img) => img.id === sponsor.id);
          return (
            <div key={sponsor.id} className="relative">
               <FloatingGermPin className="absolute -top-3 left-1/2 -translate-x-1/2 w-8 h-8" />
              <Card className="h-full flex flex-col items-center justify-center border-border/60 bg-card/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-xl text-center">{sponsor.name}</CardTitle>
                </CardHeader>
                {image && (
                  <CardContent>
                    <div className="relative w-40 h-16">
                      <Image
                        src={image.imageUrl}
                        alt={`${sponsor.name} logo`}
                        fill
                        className="object-contain"
                        data-ai-hint={image.imageHint}
                      />
                    </div>
                  </CardContent>
                )}
              </Card>
            </div>
          );
        })}
      </div>
    </div>
  );
}
