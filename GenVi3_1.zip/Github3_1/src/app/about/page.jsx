
import { PageHeader } from '@/components/page-header';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Leaf, Globe } from 'lucide-react';
import { FloatingGermPin } from '@/components/ui/floating-germ-pin';
import Image from 'next/image';
import { PlaceHolderImages } from '@/lib/placeholder-images';

export default function AboutPage() {
  const focusImage = PlaceHolderImages.find(p => p.id === 'about-focus');
  const visionImage = PlaceHolderImages.find(p => p.id === 'about-vision');

  return (
    <div className="container mx-auto px-4 py-16 relative z-10">
      <PageHeader
        title="About EcoVerse"
        subtitle="Our mission is to foster a deeper understanding of our planet and promote global health through technology and community."
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mt-16">
        <div className="relative">
          <FloatingGermPin className="absolute -top-3 left-1/2 -translate-x-1/2 w-8 h-8 z-20" />
          <Card className="bg-card/80 backdrop-blur-sm h-full overflow-hidden">
            {focusImage && (
                <div className="relative h-60">
                    <Image
                    src={focusImage.imageUrl}
                    alt={focusImage.description}
                    fill
                    className="object-cover"
                    data-ai-hint={focusImage.imageHint}
                    />
                </div>
            )}
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-2"><Leaf className="h-6 w-6 text-primary" /> Our Focus</CardTitle>
            </CardHeader>
            <CardContent className="text-muted-foreground space-y-4">
              <p>
                We are dedicated to researching and developing innovative solutions for environmental challenges. We leverage data science, AI, and community-driven initiatives to understand ecosystems, track biodiversity, and support conservation efforts worldwide.
              </p>
              <p>
                Our work involves analyzing satellite imagery, sensor data, and citizen science contributions to model and predict environmental changes, empowering policymakers and researchers with actionable insights.
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="relative">
          <FloatingGermPin className="absolute -top-3 left-1/2 -translate-x-1/2 w-8 h-8 z-20" />
          <Card className="bg-card/80 backdrop-blur-sm h-full overflow-hidden">
             {visionImage && (
                <div className="relative h-60">
                    <Image
                    src={visionImage.imageUrl}
                    alt={visionImage.description}
                    fill
                    className="object-cover"
                    data-ai-hint={visionImage.imageHint}
                    />
                </div>
            )}
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-2"><Globe className="h-6 w-6 text-accent" /> Global Vision</CardTitle>
            </CardHeader>
            <CardContent className="text-muted-foreground space-y-4">
               <p>
                EcoVerse believes in a connected world where technology and nature coexist harmoniously. We work on projects that span from local reforestation to global climate modeling.
              </p>
              <p>
                By building open-source tools and fostering a global community of environmental stewards, we aim to create a healthier, more sustainable future for all.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
