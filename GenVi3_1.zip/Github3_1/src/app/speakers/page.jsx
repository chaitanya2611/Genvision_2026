
import { PageHeader } from '@/components/page-header';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { SpeakerCard } from './speaker-card';

const speakers = [
  {
    name: 'Dr. Anya Sharma',
    title: 'Lead Ecologist',
    bio: 'With over 20 years of experience in tropical ecosystems, Dr. Sharma is a leading voice in biodiversity conservation and climate change research.',
    imageId: 'speaker-1'
  },
  {
    name: 'Ben Carter',
    title: 'Data Scientist',
    bio: 'Ben specializes in using machine learning to model environmental data, creating predictive tools that help forecast climate impacts.',
    imageId: 'speaker-2'
  },
  {
    name: 'Maria Rodriguez',
    title: 'Community Outreach Coordinator',
    bio: 'Maria connects with local communities worldwide, empowering them with the tools and knowledge to lead conservation efforts in their own backyards.',
    imageId: 'speaker-3'
  },
  {
    name: 'Kenji Tanaka',
    title: 'Software Engineer',
    bio: 'Kenji is the architect behind the EcoVerse platform, building the technology that powers our global network of environmental monitoring.',
    imageId: 'speaker-4'
  },
];

const getSpeakerWithImage = (speaker) => {
  const image = PlaceHolderImages.find(img => img.id === speaker.imageId);
  return { ...speaker, image };
}

export default function SpeakersPage() {
  return (
    <div className="container mx-auto px-4 py-16 relative z-10">
      <PageHeader
        title="Keynote Speakers"
        subtitle="Our events feature leading experts and passionate advocates in the fields of ecology, technology, and conservation."
      />
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mt-16 perspective-1000">
        {speakers.map((speaker) => (
            <SpeakerCard key={speaker.name} {...getSpeakerWithImage(speaker)} image={getSpeakerWithImage(speaker).image} />
        ))}
      </div>
    </div>
  );
}
